var color_list=['#CCCCCC','#FFC312','#009432','#EE5A24','#0652DD'];

var graph = {'ACC 101': ['ECO 248', 'FRH 101'], 'ARC 274': [],
'ART 205': ['CHM 223'], 'ART 349': [], 'BIO 201': ['CHM 303'],
'CHM 223': ['ART 205', 'ECO 248'], 'CHM 303': ['BIO 201'],
'ECO 248': ['ACC 101', 'CHM 223', 'FRH 101'],
'FRH 101': ['ACC 101', 'ECO 248'], 'ITL 101': [], 'MUS 130': [],
'FRH 330': []};

var contentArray = [];

var courseObjExample = {
  sub: "MAT",
  num: "210",
  name: "MAT210",
  crn: 12345,
  students: [111111, 22222, 333333],
  color: 0,
};

function readFiles(ev) {
    // Retrieve all the files from the FileList object
    var files = ev.target.files;
    if (files) {
        for (var i = 0, f; f = files[i]; i++) {
            var reader = new FileReader();
            reader.onload = (function (f) {
              return function (e) {
                var contents = e.target.result;
                console.log(contents);
              };
            })(f);
            reader.readAsText(f);
        }
        ev.target.nextElementSibling.nextElementSibling.innerHTML=ev.target.files.length.toString()+" file(s) selected";
    } else {
        alert("Failed to load files");
    }
}


/*
 * @param {String} HTML representing any number of sibling elements
 * @return {NodeList}
 */
function htmlToElements(html) {
    var template = document.createElement('template');
    template.innerHTML = html;
    return template.content.childNodes;
}

/*
 * @param {String} HTML representing a single element
 * @return {Element}
 */
function htmlToElement(html) {
    var template = document.createElement('template');
    html = html.trim(); // Never return a text node of whitespace as the result
    template.innerHTML = html;
    return template.content.firstChild;
}

/*
 * @param {List} of course objects
 * @return {NodeList}
 */
function createCourseCards(courses){
  if (courses) {
    for (var i = 0, c; c = courses[i]; i++) {
      if (c['name']){
        name = c['name'];
      }
      else{
        name = c['sub']+' '+c['num'];
      }
      contents ='<div class="card course" id="'+name+'">'+
              '<div class="card-body">'+
                '<p class="card-text">'+name+'</p>'+
              '</div>'+
            '</div>';
      card = htmlToElement(contents)
      if (document.getElementById(name)){
        alert('Course has already been added');
      }
      else{
        document.getElementById('course-list').appendChild(card)
        card.setAttribute('draggable', true);
        index = parseInt(c['color']);
        card.style.backgroundColor=color_list[index];
        //events fired on the draggable target
        card.addEventListener("dragstart", function( ev ) {
          //console.log(ev.target.id);
          ev.dataTransfer.setData("text", ev.target.id);
          checkConflicts(ev.target.id);
        }, false);
      }
    }
  }
}

function createCourses(){
  var result = [];
  tem = schedule(graph, blocks);
  coloring = tem[0];
  free = tem[1];
  for (var el in coloring) {
    courses = coloring[el];
    for (var i=0, c_name; c_name=courses[i]; i++) {
      c = {};
      c['color'] = el;
      c['name'] = c_name;
      result.push(c);
    }
  }
  for (var i=0, c_name; c_name=free[i]; i++) {
    c = {};
    c['color'] = 0;
    c['name'] = c_name;
    result.push(c)
  }
  createCourseCards(result);
}

function test(){
  createCourses();
}

function graphToList(graph) {
  var result = [];
  for (var el in graph) {
    result.push([el,graph[el]]);
  }
  return result
}

function Welsh_Powell(graph) {
  var graph_list = graphToList(graph);
  // sort the list by descending degree
  graph_list.sort(function(a, b){return b[1].length - a[1].length});

  // get the set of vertices in order
  var V = []
  for (var i=0, el; el=graph_list[i]; i++) {
    V.push(el[0]);
  }

  // initiate result coloring dict, with vertices as keys
  coloring = {}

  // initiate the number of color_list
  var count = 1

  // traverse the list and color the graphics
  for (var i=0, v; v=V[i]; i++){
    // if the vertex has not been colored
    if (typeof coloring[v] == "undefined") {
      // assign the first available color
      coloring[v] = count;
      // increment the count of colors
      count++;

      // traverse the list V and assign the same colors to non-neighbors of v
      for (var k=i+1, v_prime; v_prime=V[k]; k++) {
        if ((typeof coloring[v_prime] == "undefined") && !(graph[v].includes(v_prime))) {
          // check if any neighbor of v_prime is of the same color as v
          // assume there is none (which means we could still color v_prime the same as v)
          var flag = false;
          // get all neighbors of v_prime
          var neighbors = graph[v_prime];
          // if a neighbor of v_prime has the same color as v, flag = True
          for (var g=0, n; n=neighbors[g]; g++){
            if ((typeof coloring[n] != "undefined") && (coloring[n]==coloring[v])) {
              flag = true;
            }
          }
          // if v_prime doesn't have any neighbor of the same color as v
          // color v_prime as v
          if ( flag==false ){
            coloring[v_prime] = coloring[v];
          }
        }
      }
    }
  }
  //console.log(coloring);
  return coloring;
}

function schedule(graph, cb){
  var free = [];
  var V = Object.keys(graph);
  for (var i=0, v; v=V[i]; i++){
    if(graph[v].length==0) {
      free.push(v);
      delete graph[v];
    }
  }
  coloring = Welsh_Powell(graph);
  //console.log(coloring, free);
  blocks = cb(coloring);
  return [blocks, free];
}

function blocks(coloring){
  coloring_list = graphToList(coloring);
  coloring_list.sort(function(a, b){return a[1] - b[1]});
  //console.log(coloring_list);
  dict = {};
  c = coloring_list[0][1];
  for (var i=0, el; el = coloring_list[i]; i++){
    if (el[1] != c){
      c = el[1];
    }
    if (typeof dict[c] == "undefined"){
      dict[c] = [];
    }
    dict[c].push(el[0])
  }
  return dict;
}

function checkConflicts(course){
  // conflicts is a list of courses that conflict with course
  if (typeof graph[course]!= "undefined"){
    var conflicts = graph[course];
    //console.log(conflicts)
    for (var i = 0, c; c = conflicts[i]; i++){
      container = document.getElementById(c).parentNode.parentNode.parentNode;
      //console.log(container.classList);
      if (container.classList.contains("time")){
        container.style.boxShadow="0 0 5px #FF0000";
      }
    }
  }
}

window.onload = function(){
  document.getElementById('upload').addEventListener('change', readFiles, false);

  var slots = document.getElementsByClassName("dropzone");
  for (var k = 0, t; t = slots[k]; k++) {
    // events fired on the drop targets
    t.addEventListener("dragover", function( ev ) {
      // prevent default to allow drop
      ev.preventDefault();
    }, false);
    t.addEventListener("dragenter", function( ev ) {
      // highlight potential drop target when the draggable element enters it
      if (ev.target.className=="dropzone"){
        ev.target.parentNode.style.boxShadow="0 0 5px #0000FF";
      }
    }, false);
    t.addEventListener("dragleave", function( ev ) {
      // reset background of potential drop target when the draggable element leaves it
      ev.target.parentNode.style.boxShadow="";
    }, false);
    t.addEventListener("dragend", function( ev ) {
      var slots = document.getElementsByClassName("dropzone");
      for (var k = 0, t; t = slots[k]; k++) {
        t.parentNode.style.boxShadow="";
        t.parentNode.parentNode.style.boxShadow="";
      }
    }, false);
    t.addEventListener("drop", function( ev ) {
      // prevent default action (open as link for some elements)
      ev.preventDefault();
      // move dragged elem to the selected drop target           
      var data = ev.dataTransfer.getData("text");
      var flag = true;
      if(ev.target.className!="dropzone"){
        flag = false;
      }
      if (typeof graph[data] != "undefined"){
        var conflicts = graph[data];
        for (var i = 0, c; c = conflicts[i]; i++){
          container = document.getElementById(c).parentNode;
          //console.log('container: ',container)
          if (container == ev.target){
            flag = false;
          }
        }
      }
      if(flag) {
        ev.target.appendChild(document.getElementById(data));
      }
    }, false)
  }
}
